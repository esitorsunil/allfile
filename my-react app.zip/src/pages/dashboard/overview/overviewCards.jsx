import React, { useState, useEffect } from "react";
import "bootstrap/dist/css/bootstrap.min.css";

const OverviewCards = () => {
  const [dashboardData, setDashboardData] = useState({
    ordersPending: 0,
    totalRevenue: "$0",
    totalCustomers: 0,
    totalSales: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate API call
    const fetchData = async () => {
      try {
        await new Promise(resolve => setTimeout(resolve, 800));
        setDashboardData({
          ordersPending: 24,
          totalRevenue: "$48,526",
          totalCustomers: 1245,
          totalSales: 326,
        });
      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  if (loading) {
    return (
      <div className="container mt-4">
        <h2 className="mb-4">Dashboard Overview</h2>
        <div className="row g-3">
          {[1, 2, 3, 4].map((item) => (
            <div className="col-md-3" key={item}>
              <div className="card border-opacity-10 border-1 border-dark">
                <div className="card-body">
                  <div className="placeholder-glow">
                    <h6 className="card-title placeholder col-6"></h6>
                    <h3 className="mb-0 placeholder col-4"></h3>
                    <p className="card-text placeholder col-10 mt-2"></p>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="container mt-4">
      <h2 className="mb-4">Dashboard Overview</h2>
      <div className="row g-3">
        {/* Orders Pending Card */}
        <div className="col-md-3">
          <div className="card border-opacity-10 border-1 border-dark">
            <div className="card-body">
              <div className="d-flex justify-content-between align-items-center">
                <div>
                  <h6 className="card-title text-muted text-uppercase small">
                    Orders Pending
                  </h6>
                  <h3 className="mb-0 fw-bold">{dashboardData.ordersPending}</h3>
                </div>
                <div className="bg-primary bg-opacity-10 p-3 rounded-4">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="20"
                    height="20"
                    fill="currentColor"
                    className="bi bi-cart text-primary"
                    viewBox="0 0 16 16"
                  >
                    <path d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .491.592l-1.5 8A.5.5 0 0 1 13 12H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5zM3.102 4l1.313 7h8.17l1.313-7H3.102zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2zm7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2z" />
                  </svg>
                </div>
              </div>
              <p className="card-text text-muted mt-2 small">
                <span className="text-success">↑ 5%</span> from yesterday
              </p>
            </div>
          </div>
        </div>

        {/* Total Revenue Card */}
        <div className="col-md-3">
          <div className="card border-opacity-10 border-1 border-dark">
            <div className="card-body">
              <div className="d-flex justify-content-between align-items-center">
                <div>
                  <h6 className="card-title text-muted text-uppercase small">
                    Total Revenue
                  </h6>
                  <h3 className="mb-0 fw-bold">{dashboardData.totalRevenue}</h3>
                </div>
                <div className="bg-success bg-opacity-10 p-3 rounded-4">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="20"
                    height="20"
                    fill="currentColor"
                    className="bi bi-currency-dollar text-success"
                    viewBox="0 0 16 16"
                  >
                    <path d="M4 10.781c.148 1.667 1.513 2.85 3.591 3.003V15h1.043v-1.216c2.27-.179 3.678-1.438 3.678-3.3 0-1.59-.947-2.51-2.956-3.028l-.722-.187V3.467c1.122.11 1.879.714 2.07 1.616h1.47c-.166-1.6-1.54-2.748-3.54-2.875V1H7.591v1.233c-1.939.23-3.27 1.472-3.27 3.156 0 1.454.966 2.483 2.661 2.917l.61.162v4.031c-1.149-.17-1.94-.8-1.94-1.9 0-.979.758-1.698 1.923-1.858l1.852-.064z" />
                  </svg>
                </div>
              </div>
              <p className="card-text text-muted mt-2 small">
                <span className="text-success">↑ 12%</span> from last month
              </p>
            </div>
          </div>
        </div>

        {/* Total Customers Card */}
        <div className="col-md-3">
          <div className="card border-opacity-10 border-1 border-dark">
            <div className="card-body">
              <div className="d-flex justify-content-between align-items-center">
                <div>
                  <h6 className="card-title text-muted text-uppercase small">
                    Total Customers
                  </h6>
                  <h3 className="mb-0 fw-bold">{dashboardData.totalCustomers}</h3>
                </div>
                <div className="bg-info bg-opacity-10 p-3 rounded-4">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="20"
                    height="20"
                    fill="currentColor"
                    className="bi bi-people text-info"
                    viewBox="0 0 16 16"
                  >
                    <path d="M15 14s1 0 1-1-1-4-5-4-5 3-5 4 1 1 1 1h8zm-7.978-1A.261.261 0 0 1 7 12.996c.001-.264.167-1.03.76-1.72C8.312 10.629 9.282 10 11 10c1.717 0 2.687.63 3.24 1.276.593.69.758 1.457.76 1.72l-.008.002a.274.274 0 0 1-.014.002H7.022zM11 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4z" />
                    <path d="M9 13a2 2 0 1 0 0-4 2 2 0 0 0 0 4z" />
                  </svg>
                </div>
              </div>
              <p className="card-text text-muted mt-2 small">
                <span className="text-success">↑ 8%</span> from last quarter
              </p>
            </div>
          </div>
        </div>

        {/* Total Sales Card */}
        <div className="col-md-3">
          <div className="card border-opacity-10 border-1 border-dark">
            <div className="card-body">
              <div className="d-flex justify-content-between align-items-center">
                <div>
                  <h6 className="card-title text-muted text-uppercase small">
                    Total Sales
                  </h6>
                  <h3 className="mb-0 fw-bold">{dashboardData.totalSales}</h3>
                </div>
                <div className="bg-warning bg-opacity-10 p-3 rounded-4">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="20"
                    height="20"
                    fill="currentColor"
                    className="bi bi-graph-up text-warning"
                    viewBox="0 0 16 16"
                  >
                    <path
                      fillRule="evenodd"
                      d="M0 0h1v15h15v1H0V0zm10 3.5a.5.5 0 0 1 .5-.5h4a.5.5 0 0 1 .5.5v4a.5.5 0 0 1-1 0V4.9l-3.613 4.417a.5.5 0 0 1-.74.037L7.06 6.767l-3.656 5.027a.5.5 0 0 1-.808-.588l4-5.5a.5.5 0 0 1 .758-.06l2.609 2.61L13.445 4H10.5a.5.5 0 0 1-.5-.5z"
                    />
                  </svg>
                </div>
              </div>
              <p className="card-text text-muted mt-2 small">
                <span className="text-success">↑ 15%</span> from last week
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OverviewCards;