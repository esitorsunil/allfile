import React, { useState, useEffect } from 'react';
import { Bar } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

const OverviewPatterns = () => {
  const [timePeriod, setTimePeriod] = useState('month');
  const [revenueData, setRevenueData] = useState(null);
  const [topCustomers, setTopCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Fetch data from json-server
  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      
      // Fetch revenue data
      const revenueResponse = await fetch('http://localhost:3001/dashboard/revenue');
      if (!revenueResponse.ok) throw new Error('Failed to load revenue data');
      const revenueData = await revenueResponse.json();
      
      // Fetch top customers
      const customersResponse = await fetch('http://localhost:3001/dashboard/topCustomers');
      if (!customersResponse.ok) throw new Error('Failed to load customers data');
      const topCustomers = await customersResponse.json();
      
      setRevenueData(revenueData);
      setTopCustomers(topCustomers);
      
    } catch (err) {
      console.error('Error fetching dashboard data:', err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, []);

  if (loading) {
    return (
      <div className="container-fluid mt-4">
        <div className="row">
          <div className="col-md-8 mb-4">
            <div className="card h-100">
              <div className="card-body">
                <div className="placeholder-glow">
                  <div className="placeholder col-3 mb-3" style={{height: '30px'}}></div>
                  <div className="placeholder" style={{height: '300px'}}></div>
                </div>
              </div>
            </div>
          </div>
          <div className="col-md-4 mb-4">
            <div className="card h-100">
              <div className="card-body">
                <div className="placeholder-glow">
                  <div className="placeholder col-3 mb-3" style={{height: '30px'}}></div>
                  {[1, 2, 3, 4, 5].map((item) => (
                    <div key={item} className="placeholder mb-2" style={{height: '60px'}}></div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container-fluid mt-4">
        <div className="alert alert-danger">{error}</div>
      </div>
    );
  }

  // Chart configuration
  const chartData = {
    labels: revenueData[timePeriod].labels,
    datasets: [
      {
        label: 'Revenue (₹)',
        data: revenueData[timePeriod].data,
        backgroundColor: 'rgba(54, 162, 235, 0.7)',
        borderColor: 'rgba(54, 162, 235, 1)',
        borderWidth: 1,
      },
    ],
  };

  const chartOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top',
      },
      tooltip: {
        callbacks: {
          label: function(context) {
            return '₹' + context.raw.toLocaleString('en-IN');
          }
        }
      }
    },
    scales: {
      y: {
        beginAtZero: true,
        ticks: {
          callback: function(value) {
            return '₹' + value.toLocaleString('en-IN');
          }
        }
      },
    },
  };

  return (
    <div className="container-fluid mt-4">
      <div className="row">
        {/* Revenue Overview Card */}
        <div className="col-md-8 mb-4">
          <div className="card h-100">
            <div className="card-header bg-white border-bottom">
              <div className="d-flex justify-content-between align-items-center">
                <h5 className="mb-0">Revenue Overview</h5>
                <div className="btn-group" role="group">
                  <button
                    type="button"
                    className={`btn btn-sm ${timePeriod === 'week' ? 'btn-primary' : 'btn-outline-secondary'}`}
                    onClick={() => setTimePeriod('week')}
                  >
                    Week
                  </button>
                  <button
                    type="button"
                    className={`btn btn-sm ${timePeriod === 'month' ? 'btn-primary' : 'btn-outline-secondary'}`}
                    onClick={() => setTimePeriod('month')}
                  >
                    Month
                  </button>
                  <button
                    type="button"
                    className={`btn btn-sm ${timePeriod === 'year' ? 'btn-primary' : 'btn-outline-secondary'}`}
                    onClick={() => setTimePeriod('year')}
                  >
                    Year
                  </button>
                </div>
              </div>
            </div>
            <div className="card-body">
              <div className="chart-container" style={{ height: '300px', position: 'relative' }}>
                <Bar data={chartData} options={chartOptions} />
              </div>
            </div>
            <div className="card-footer bg-white border-top">
              <div className="row text-center">
                <div className="col-4">
                  <div className="text-muted small">This {timePeriod}</div>
                  <div className="fw-bold">
                    ₹{revenueData[timePeriod].data.reduce((a, b) => a + b, 0).toLocaleString('en-IN')}
                  </div>
                </div>
                <div className="col-4">
                  <div className="text-muted small">Avg. per {timePeriod === 'week' ? 'day' : timePeriod === 'month' ? 'week' : 'month'}</div>
                  <div className="fw-bold">
                    ₹{Math.round(revenueData[timePeriod].data.reduce((a, b) => a + b, 0) / 
                      (timePeriod === 'week' ? 7 : timePeriod === 'month' ? 4 : 12)).toLocaleString('en-IN')}
                  </div>
                </div>
                <div className="col-4">
                  <div className="text-muted small">Highest</div>
                  <div className="fw-bold">
                    ₹{Math.max(...revenueData[timePeriod].data).toLocaleString('en-IN')}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Top Customers Card */}
        <div className="col-md-4 mb-4">
          <div className="card h-100">
            <div className="card-header bg-white border-bottom">
              <h5 className="mb-0">Top Customers</h5>
            </div>
            <div className="card-body p-0">
              <div className="list-group list-group-flush">
                {topCustomers.map((customer) => (
                  <div key={customer.id} className="list-group-item border-0 py-3">
                    <div className="d-flex justify-content-between align-items-center">
                      <div>
                        <h6 className="mb-1">{customer.name}</h6>
                        <small className="text-muted">{customer.purchases} purchases</small>
                      </div>
                      <div className="fw-bold text-success">
                        ₹{customer.amount.toLocaleString('en-IN')}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="card-footer bg-white border-top text-center">
              <a href="#!" className="text-primary">View all customers</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OverviewPatterns;