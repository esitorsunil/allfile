import React from 'react'
import OverviewCards from './overview/overviewCards'
import OverviewPatterns from './overview/overviewPatterns'

const Overview = () => {
  return (
    <div>
      <OverviewCards/>
      <OverviewPatterns/>
    </div>
  )
}

export default Overview
