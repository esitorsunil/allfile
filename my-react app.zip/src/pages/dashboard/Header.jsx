// components/Header.jsx
import React from 'react';
import { Navbar, Button } from 'react-bootstrap';

const Header = ({ toggleSidebar }) => {
  return (
    <Navbar bg="dark" variant="dark" className="px-3 shadow-sm justify-content-between">
      <Button variant="outline-none" onClick={toggleSidebar}>
        <img src="../../public/images/hamburger.png"/>
      </Button>
      <Navbar.Brand className="text-white fw-semibold fs-5">Admin Dashboard</Navbar.Brand>
    </Navbar>
  );
};

export default Header;
