import 'bootstrap/dist/css/bootstrap.min.css';
import 'react-quill/dist/quill.snow.css';

const Toolbar = ({ onUndo, onRedo }) => (
    
  <div id="toolbar-container" className="d-flex flex-wrap gap-2 p-3 rounded">
    <button className="ql-image"></button>

    <select className="ql-header" defaultValue="">
      <option value="1">Heading 1</option>
      <option value="2">Heading 2</option>
      <option value="">Paragraph</option>
    </select>

    <select className="ql-size" defaultValue="medium">
      <option value="small">12px</option>
      <option value="medium">16px</option>
      <option value="large">20px</option>
      <option value="huge">24px</option>
    </select>

    <button className="ql-bold" />
    <button className="ql-italic" />
    <button className="ql-underline" />
    <button className="ql-link" />
    <button className="ql-list" value="ordered" />
    <button className="ql-list" value="bullet" />
    <button className="ql-align" value="" />
    <button className="ql-align" value="center" />
    <button className="ql-align" value="right" />
    <button className="ql-align" value="justify" />

    <button type="button" onClick={onUndo} className="btn btn-outline-secondary">
      <i className="bi bi-arrow-90deg-left" />
    </button>
    <button type="button" onClick={onRedo} className="btn btn-outline-secondary">
      <i className="bi bi-arrow-90deg-right" />
    </button>
  </div>
);

export default Toolbar;
