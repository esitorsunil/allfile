# 🌐 Auto Translate Dropdown

A lightweight React component to instantly translate visible text on your webpage using the [MyMemory Translation API](https://mymemory.translated.net/). This component injects a floating language dropdown and dynamically replaces all text on the page.


## ✨ Features

- Automatically translates visible text content
- Saves and restores original text
- Simple, floating dropdown interface
- Supports 100+ languages
- No external dependencies other than `React`

---

## 📦 Usage

```bash

import React from "react";
import AutoTranslateDropdown from "custom-react-auto-translate-dropdown";

function App() {
  return (
    <div>
      <AutoTranslateDropdown />
      <h1>Welcome to My Website</h1>
      <p>This is an example paragraph that will be translated.</p>
    </div>
  );
}

export default App;
```
---
## License

MIT © [esitorsunil](https://github.com/esitorsunil)


