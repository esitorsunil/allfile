// Toggle Skills Visibility
function toggleSkills() {
    const list = document.getElementById("skills-list");
    list.style.display = list.style.display === "none" ? "block" : "none";
  }
  
  // Contact Form Validation
  function validateForm() {
    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("email").value.trim();
    const message = document.getElementById("message").value.trim();
  
    if (!name || !email || !message) {
      alert("Please fill in all fields.");
      return false;
    }
  
    // Simple email format check
    const emailRegex = /^[^@]+@[^@]+\.[^@]+$/;
    if (!emailRegex.test(email)) {
      alert("Please enter a valid email address.");
      return false;
    }
  
    alert("Form submitted successfully!");
    return true;
  }
  