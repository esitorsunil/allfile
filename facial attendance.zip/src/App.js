import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import HomePage from './components/Home';
import RegisterFace from './components/RegisterFace';
import FaceScanner from './components/FaceAttendance';

const App = () => (
  <Router>
    <Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/register" element={<RegisterFace />} />
      <Route path="/scan" element={<FaceScanner />} />
    </Routes>
  </Router>
);

export default App;
