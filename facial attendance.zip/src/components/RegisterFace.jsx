import React, { useEffect, useRef, useState } from 'react';
import * as faceapi from 'face-api.js';
import { Box, Button, TextField, Typography } from '@mui/material';

const RegisterFace = () => {
  const videoRef = useRef();
  const [name, setName] = useState('');

  useEffect(() => {
    const loadModels = async () => {
      const MODEL_URL = '/models';
      await Promise.all([
        faceapi.nets.tinyFaceDetector.loadFromUri(MODEL_URL),
        faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_URL),
        faceapi.nets.faceLandmark68Net.loadFromUri(MODEL_URL)
      ]);
      startVideo();
    };

    loadModels();
  }, []);

  const startVideo = () => {
    navigator.mediaDevices.getUserMedia({ video: {} })
      .then(stream => videoRef.current.srcObject = stream)
      .catch(err => console.error('Camera Error', err));
  };

  const handleCapture = async () => {
    const detection = await faceapi
      .detectSingleFace(videoRef.current, new faceapi.TinyFaceDetectorOptions())
      .withFaceLandmarks()
      .withFaceDescriptor();

    if (!detection || !name.trim()) {
      alert('Face not detected or name is empty.');
      return;
    }

    const descriptor = detection.descriptor;
    const storedData = JSON.parse(localStorage.getItem('faceData') || '{}');
    storedData[name] = Array.from(descriptor);
    localStorage.setItem('faceData', JSON.stringify(storedData));

    alert(`Face of "${name}" registered successfully!`);
    setName('');
  };

  return (
    <Box textAlign="center" mt={4}>
      <video ref={videoRef} autoPlay muted width={480} height={360} style={{ border: '2px solid gray' }} />
      <Box mt={2}>
        <TextField
          label="Enter Name"
          value={name}
          onChange={e => setName(e.target.value)}
        />
        <Button onClick={handleCapture} variant="contained" color="success" sx={{ ml: 2 }}>
          Capture Face
        </Button>
      </Box>
    </Box>
  );
};

export default RegisterFace;
