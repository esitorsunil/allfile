import { Button, Box } from '@mui/material';
import { useNavigate } from 'react-router-dom';

const HomePage = () => {
  const navigate = useNavigate();

  return (
    <Box textAlign="center" mt={5}>
      <Button
        variant="contained"
        color="primary"
        onClick={() => navigate('/register')}
      >
        Register New Face
      </Button>
    </Box>
  );
};

export default HomePage;
