import React, { useEffect, useRef, useState } from 'react';
import * as faceapi from 'face-api.js';
import { Box, Typography } from '@mui/material';
import dayjs from 'dayjs';

const FaceScanner = () => {
  const videoRef = useRef();
  const [attendance, setAttendance] = useState([]);

  useEffect(() => {
    const loadModels = async () => {
      const MODEL_URL = '/models'; // Place models in public/models
      await Promise.all([
        faceapi.nets.tinyFaceDetector.loadFromUri(MODEL_URL),
        faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_URL),
        faceapi.nets.faceLandmark68Net.loadFromUri(MODEL_URL)
      ]);

      startVideo();
    };

    loadModels();
  }, []);

  const startVideo = () => {
    navigator.mediaDevices.getUserMedia({ video: {} })
      .then(stream => videoRef.current.srcObject = stream)
      .catch(err => console.error("Camera error:", err));
  };

  const handleVideoPlay = async () => {
    const labeledDescriptors = loadLabeledDescriptors();
    const faceMatcher = new faceapi.FaceMatcher(labeledDescriptors, 0.6);

    setInterval(async () => {
      const detections = await faceapi
        .detectAllFaces(videoRef.current, new faceapi.TinyFaceDetectorOptions())
        .withFaceLandmarks()
        .withFaceDescriptors();

      const results = detections.map(d => faceMatcher.findBestMatch(d.descriptor));
      results.forEach((result) => {
        if (result.label !== 'unknown') {
          const name = result.label;
          const time = dayjs().format('HH:mm:ss');

          // Avoid duplicate entries
          setAttendance(prev => {
            if (prev.some(entry => entry.name === name && entry.time === time)) return prev;
            const updated = [...prev, { name, time }];
            localStorage.setItem('attendance', JSON.stringify(updated));
            return updated;
          });
        }
      });
    }, 3000);
  };

  const loadLabeledDescriptors = () => {
    const data = JSON.parse(localStorage.getItem('faceData') || '{}');
    return Object.entries(data).map(([name, descriptor]) =>
      new faceapi.LabeledFaceDescriptors(name, [new Float32Array(descriptor)])
    );
  };

  return (
    <Box>
      <video
        ref={videoRef}
        autoPlay
        muted
        onPlay={handleVideoPlay}
        width="720"
        height="560"
        style={{ borderRadius: '10px', border: '2px solid #ccc' }}
      />
      <Typography mt={2} variant="h6">Attendance Marked:</Typography>
      {attendance.map((entry, i) => (
        <Typography key={i}>{entry.name} - {entry.time}</Typography>
      ))}
    </Box>
  );
};

export default FaceScanner;
