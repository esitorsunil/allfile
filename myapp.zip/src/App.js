import AutoTranslateDropdown from "custom-react-auto-translate-dropdown";

function App() {
  return (
    <div>
      <AutoTranslateDropdown />
      <h1>Welcome to My Website</h1>
      <p>This is an example paragraph that will be translated.</p>
    </div>
  );
}

export default App;