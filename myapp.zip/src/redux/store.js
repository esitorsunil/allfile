import { configureStore } from '@reduxjs/toolkit';
import { languageReducer } from 'redux-language-mymemory';

export const store = configureStore({
  reducer: {
    language: languageReducer,
  },
});