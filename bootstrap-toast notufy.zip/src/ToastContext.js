import React, { createContext, useState, useContext } from 'react';
import ToastNotifications from './ToastNotifications';

const ToastContext = createContext();

export const ToastProvider = ({ children }) => {
  const [toasts, setToasts] = useState([]);

  const addToast = (type, title, message) => {
    const id = Date.now();
    setToasts([...toasts, { id, type, title, message }]);
    return id;
  };

  const removeToast = (id) => {
    setToasts(toasts.filter((toast) => toast.id !== id));
  };

  const success = (message, title = 'Success') => {
    return addToast('success', title, message);
  };

  const info = (message, title = 'Info') => {
    return addToast('info', title, message);
  };

  const warning = (message, title = 'Warning') => {
    return addToast('warning', title, message);
  };

  const error = (message, title = 'Error') => {
    return addToast('danger', title, message);
  };

  return (
    <ToastContext.Provider value={{ success, info, warning, error, removeToast }}>
      {children}
      <ToastNotifications toasts={toasts} onClose={removeToast} />
    </ToastContext.Provider>
  );
};

export const useToast = () => {
  return useContext(ToastContext);
};