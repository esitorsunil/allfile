import React from 'react';
import { ToastContainer, Toast } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';

const ToastNotifications = ({ toasts, onClose }) => {
  return (
    <ToastContainer position="top-end" className="p-3" style={{ zIndex: 1 }}>
      {toasts.map((toast) => (
        <Toast
          key={toast.id}
          onClose={() => onClose(toast.id)}
          show={true}
          delay={3000}
          autohide
          bg={toast.type}
        >
          <Toast.Header>
            <strong className="me-auto">{toast.title}</strong>
          </Toast.Header>
          <Toast.Body className="text-white">{toast.message}</Toast.Body>
        </Toast>
      ))}
    </ToastContainer>
  );
};

export default ToastNotifications;