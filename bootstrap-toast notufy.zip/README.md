# bootstrap-toast-notifications

> Made with create-react-library

[![NPM](https://img.shields.io/npm/v/bootstrap-toast-notifications.svg)](https://www.npmjs.com/package/bootstrap-toast-notifications) [![JavaScript Style Guide](https://img.shields.io/badge/code_style-standard-brightgreen.svg)](https://standardjs.com)

## Install

```bash
npm install --save bootstrap-toast-notifications
```

## Usage

```jsx
import React, { Component } from 'react'

import MyComponent from 'bootstrap-toast-notifications'
import 'bootstrap-toast-notifications/dist/index.css'

class Example extends Component {
  render() {
    return <MyComponent />
  }
}
```

## License

MIT © [esitorsunil](https://github.com/esitorsunil)
