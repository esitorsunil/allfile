var a =10

{
    var a =100;
    let b =10;
    const c = 20;
    console.log(a)
    console.log(b)
    console.log(c)
}

console.log(a)

// console.log(b); //not defined

//shadowing in block scope
var d =100;
{
    let d=10;
    console.log(d);
}

console.log(d);

//lexical block scope

const e = 1000

{
    const e =10
    {
        const e = 200
        console.log(e)
    }
}

console.log(e)