
function x(){
    var a = 10;
    function y(){
      console.log(a)
    }
     y();
}
x();


console.log("JS")



function c(){
    var c = 10
    function d(){
      console.log(c)
    }
    c = 100
    return d;
}

var z = c()

z();


