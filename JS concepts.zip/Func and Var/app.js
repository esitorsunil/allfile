var x = 1
a()
b()
console.log(x)

function a () {
    var x =10
    console.log(10)
}

function b() {
    var x = 100
    console.log(1000)
}