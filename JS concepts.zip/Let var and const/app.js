

// console.log(x)  //not defined  Reference Error


console.log(a) //undefined
var a = 10;

let b = 10

//let b = 20 syntax js file run with single line of code

b=20 //we can reassign
console.log(b);

const c =2000;

console.log(c)

c = 200 //we cant reassign the const Typeerror

