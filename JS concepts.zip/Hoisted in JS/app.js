
getName()
getNames() // Type error: getnames is not a func
console.log(x)
console.log(getName)
console.log(getNames)


var x =7
function getName() {
    var a = 10;
}


//var getName = () =>{console.log(10)} it will not work (same as in normal function)

var getNames = () =>{console.log(10)} 