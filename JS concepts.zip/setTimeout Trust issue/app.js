console.log("start")

setTimeout(function(){
    console.log("JS")
},0)

console.log("end")