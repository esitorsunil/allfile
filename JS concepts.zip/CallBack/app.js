
setTimeout(() => {
    console.log("JS")
},5000)

function y(x) {
  console.log(1)
  x()
}

y(function x() {
    console.log(2);
})


function attachEvent(){
    let count = 0;
      document.getElementById("clickme")
      .addEventListener("click",function xyz(){
        console.log("clicked", count);
    })
    }
    attachEvent();