
import { createSlice } from '@reduxjs/toolkit';

const initialLang = localStorage.getItem('app_lang') || 'en';

const languageSlice = createSlice({
  name: 'language',
  initialState: {
    currentLang: initialLang,
  },
  reducers: {
    setLanguage: (state, action) => {
      state.currentLang = action.payload;
      localStorage.setItem('app_lang', action.payload); 
    },
  },
});

export const { setLanguage } = languageSlice.actions;
export default languageSlice.reducer;
