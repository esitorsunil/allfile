import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Header from "./components/Header";
import Home from "./layout/Home";
import About from "./layout/About";
import Contact from "./layout/Contact";
import AutoTranslateDropdown from "./components/memoryApi";


function App() {
  return (
 
    <Router>
      <Header />
       <AutoTranslateDropdown />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />
       
      </Routes>
    </Router>
   
  );
}

export default App;