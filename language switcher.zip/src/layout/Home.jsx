
const Home = () => {
  return (
    <div className="center">
      <h1>Hello, welcome to our site!</h1>
      <p>This content will be translated based on the selected language.</p>
    </div>
  );
};

export default Home;
