import React, { useEffect, useRef } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useLocation } from 'react-router-dom';
import { setLanguage } from '../utils/languageSlice';

function AutoTranslateDropdown() {
  const lang = useSelector((state) => state.language.currentLang);
  const dispatch = useDispatch();
  const originalTextMap = useRef(new Map());
  const location = useLocation();

  const translateText = async (text, sourceLang, targetLang) => {
    if (sourceLang === targetLang) return text;

    const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(
      text
    )}&langpair=${sourceLang}|${targetLang}`;

    try {
      const res = await fetch(url);
      const data = await res.json();
      if (
        data?.responseData?.translatedText?.includes("PLEASE SELECT TWO DISTINCT LANGUAGES")
      ) {
        return text;
      }
      return data?.responseData?.translatedText || text;
    } catch (err) {
      return text;
    }
  };

  const handleTranslation = async (targetLang) => {
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    const textNodes = [];

    while (walker.nextNode()) {
      const node = walker.currentNode;
      const parent = node.parentElement;

      if (
        node.nodeValue.trim() &&
        !parent.closest("#translator-dropdown") &&
        !parent.matches("script, style, noscript")
      ) {
        textNodes.push(node);
      }
    }

    await Promise.all(
      textNodes.map(async (node) => {
        const original =
          originalTextMap.current.get(node) || node.nodeValue;

        if (!originalTextMap.current.has(node)) {
          originalTextMap.current.set(node, original);
        }

        if (targetLang === 'en') {
          node.nodeValue = original;
        } else {
          const translated = await translateText(original, 'en', targetLang);
          node.nodeValue = translated;
        }
      })
    );
  };

  useEffect(() => {
    handleTranslation(lang);
  }, [lang, location.pathname]); 

  return (
    <div
      id="translator-dropdown"
      style={{
        position: "fixed",
        top: 10,
        right: 10,
        background: "#fff",
        padding: "6px 12px",
        borderRadius: "6px",
        boxShadow: "0 0 4px rgba(0,0,0,0.1)",
        zIndex: 9999,
      }}
    >
      <label style={{ marginRight: "8px" }}>🌐 Language:</label>
      <select
        value={lang}
        onChange={(e) => dispatch(setLanguage(e.target.value))}
      >
        <option value="en">English</option>
        <option value="hi">Hindi</option>
        <option value="ta">Tamil</option>
        <option value="te">Telugu</option>
        <option value="ml">Malayalam</option>
        <option value="fr">French</option>
        <option value="es">Spanish</option>
        <option value="de">German</option>
        <option value="zh">Chinese (Simplified)</option>
        <option value="ar">Arabic</option>
      </select>
    </div>
  );
}

export default AutoTranslateDropdown;
