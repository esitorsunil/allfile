# 🧠 Redux Toolkit in React Applications

Redux Toolkit is the official, recommended approach for writing Redux logic. It standardizes the way to write Redux code and simplifies store setup, reducer logic, and asynchronous actions.

---

## 📌 WHEN to Use Redux Toolkit?

Use Redux Toolkit when:

- Your app has **global/shared state** (e.g., auth, user, theme, language).
- You need **consistent state updates** across deeply nested components.
- Your app involves **API data fetching** (e.g., with Redux Thunk or RTK Query).
- Local component state is not sufficient.
- You want **predictable state management**, debugging, or time-travel debugging.

❌ Don’t use Redux Toolkit if:
- Your app has very simple state needs that can be handled with `useState` or `useContext`.

---

## 🔍 WHAT is Redux Toolkit?

Redux Toolkit (RTK) is a **standardized way** to write Redux logic. It comes with:

- `configureStore()` – Simplifies store creation.
- `createSlice()` – Generates reducers + actions in one go.
- `createAsyncThunk()` – Simplifies async logic (e.g., API calls).
- `createEntityAdapter()` – Helps with normalized state.
- `RTK Query` – Powerful data fetching & caching.

Other useful APIs & utilities in Redux Toolkit:
createReducer() — Utility to create reducers using a builder callback or map of action handlers.

- createAction() — Utility to create action creators manually.

- isAnyOf(), isAllOf(), isPending(), isRejected(), isFulfilled() — Matchers to simplify reducer logic especially with async thunks.

- createListenerMiddleware() — Middleware to handle side effects reactively in response to actions.

- unwrapResult() — Helper to get the fulfilled payload or throw errors from async thunks results.

- nanoid — Tiny ID generator integrated for creating unique IDs.

---

## ⚙️ HOW to Use Redux Toolkit?

### 1. Install

```bash
npm install @reduxjs/toolkit react-redux