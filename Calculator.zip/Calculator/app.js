function calculate() {
    const num1 = document.getElementById("num1").value.trim();
    const num2 = document.getElementById("num2").value.trim();
    const operation = document.getElementById("operation").value;
    const resultField = document.getElementById("result");
    const errorField = document.getElementById("error");

    resultField.textContent = '';
    errorField.textContent = '';

    
    if (num1 === '' || num2 === '') {
      errorField.textContent = "Both numbers are required.";
      return;
    }

    const a = parseFloat(num1);
    const b = parseFloat(num2);

    if (isNaN(a) || isNaN(b)) {
      errorField.textContent = "Please enter valid numbers.";
      return;
    }

    if (operation === '/' && b === 0) {
      errorField.textContent = "Cannot divide by zero.";
      return;
    }

    let result;
    switch (operation) {
      case '+':
        result = a + b;
        break;
      case '-':
        result = a - b;
        break;
      case '*':
        result = a * b;
        break;
      case '/':
        result = a / b;
        break;
      default:
        errorField.textContent = "Invalid operation.";
        return;
    }

    resultField.textContent = `Result: ${result}`;
  }