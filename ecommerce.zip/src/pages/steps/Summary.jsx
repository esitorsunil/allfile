

const Summary = () => (
  <div>
    <h4>Summary</h4>
    <p>Review your order and place it.</p>
    <button className="btn btn-success">Place Order</button>
  </div>
);
export default Summary;