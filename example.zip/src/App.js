import React from 'react'

import { ExampleComponent } from 'bootstrap-toast-notifications'
import 'bootstrap-toast-notifications/dist/index.css'

const App = () => {
  return <ExampleComponent text="Create React Library Example 😄" />
}

export default App
