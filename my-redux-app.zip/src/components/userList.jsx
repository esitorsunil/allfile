// src/features/UserList.jsx
import React, { useState } from 'react';
import {
  useGetUsersQuery,
  useAddUserMutation,
} from '../utils/usersSlice';

const UserList = () => {
  const { data: users = [], isLoading, error } = useGetUsersQuery();
  const [addUser] = useAddUserMutation();

  const [newUserName, setNewUserName] = useState('');

  const handleAddUser = () => {
    if (newUserName.trim()) {
      addUser({ name: newUserName });
      setNewUserName('');
    }
  };

  return (
    <div style={{ padding: 20 }}>
      <h2>Users List</h2>

      {isLoading && <p>Loading...</p>}
      {error && <p>Error loading users</p>}

      <ul>
        {users.map((user) => (
          <li key={user.id}>{user.name}</li>
        ))}
      </ul>

      <input
        value={newUserName}
        onChange={(e) => setNewUserName(e.target.value)}
        placeholder="New user name"
      />
      <button onClick={handleAddUser}>Add User</button>
    </div>
  );
};

export default UserList;
