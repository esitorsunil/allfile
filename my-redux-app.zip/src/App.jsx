import { Routes, Route, useNavigate } from 'react-router-dom';
import UsersList from './components/userList';


function Home() {
  const navigate = useNavigate();

  return (
    <div>
      <h1>Redux Toolkit Demo</h1>
      <button onClick={() => navigate('/users')}>createAsyncThunk , createEntityAdapter, createSlice  Redux</button>
    </div>
  );
}

function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/users" element={<UsersList />} />
    </Routes>
  );
}

export default App;
