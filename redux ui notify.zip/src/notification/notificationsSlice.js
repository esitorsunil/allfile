import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  items: [],
};

const notificationsSlice = createSlice({
  name: 'notifications',
  initialState,
  reducers: {
    pushNotification: (state, action) => {
      state.items.push(action.payload);
    },
    removeNotification: (state, action) => {
      state.items = state.items.filter(n => n.id !== action.payload);
    },
    clearNotifications: (state) => {
      state.items = [];
    },
  },
});

export const { pushNotification, removeNotification, clearNotifications } = notificationsSlice.actions;
export const notificationsReducer = notificationsSlice.reducer;