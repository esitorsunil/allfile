import React, { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { removeNotification } from './notificationsSlice';

export const NotificationsPanel = () => {
  const notifications = useSelector((state) => state.notifications.items);
  const dispatch = useDispatch();

  useEffect(() => {
    // For every notification, set a timer to remove it after 5 seconds
    notifications.forEach((n) => {
      const timer = setTimeout(() => {
        dispatch(removeNotification(n.id));
      }, 5000);

      // Cleanup function in case notification disappears early or component unmounts
      return () => clearTimeout(timer);
    });
  }, [notifications, dispatch]);

  return (
    <div style={{ position: 'fixed', top: 10, right: 10, zIndex: 1000 }}>
      {notifications.map((n) => (
        <div
          key={n.id}
          style={{
            background:
              n.type === 'error'
                ? '#f44336'
                : n.type === 'success'
                ? '#4caf50'
                : '#2196f3',
            color: '#fff',
            padding: '10px 15px',
            marginBottom: 8,
            borderRadius: 4,
            minWidth: 200,
            boxShadow: '0 2px 4px rgba(0,0,0,0.3)',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
          }}
        >
          <span>{n.message}</span>
          <button
            onClick={() => dispatch(removeNotification(n.id))}
            style={{
              marginLeft: 10,
              background: 'transparent',
              border: 'none',
              color: '#fff',
              cursor: 'pointer',
              fontWeight: 'bold',
              fontSize: '16px',
              lineHeight: '16px',
            }}
            aria-label="Close notification"
          >
            ×
          </button>
        </div>
      ))}
    </div>
  );
};
