import React from 'react';
import DocumentHeader from '../DocumentHeader';
import ComposeSidebar from './ComposeSideBar';
import ComposeBody from './ComposeBody';

const ComposePage = () => {
  return (
    <>
      <DocumentHeader />
      <ComposeSidebar/>
      <ComposeBody/>
    </>
  );
};

export default ComposePage;