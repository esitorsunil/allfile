import React from 'react';
import DocumentHeader from '../DocumentHeader';

const FinalizePage = () => {
  return (
    <>
      <DocumentHeader />
      <h2 className="text-center">Finalize Page</h2>

    </>
  );
};

export default FinalizePage;