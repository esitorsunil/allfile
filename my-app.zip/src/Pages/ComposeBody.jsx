import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

const ComposeBody = () => {
  const [isWebEditor, setIsWebEditor] = useState(true); // To toggle between Web Editor and MS Word

  // Handle Web Editor and MS Word toggle
  const handleToggle = () => {
    setIsWebEditor(prevState => !prevState);
  };

  return (
    <div className="container mt-4">
      <div className="row">
        <div className="col-12 d-flex justify-content-between align-items-center">
          <h3>Compose Body</h3>
          
          {/* Switches for Web Editor and MS Word */}
          <div>
            <label className="switch">
              <input 
                type="checkbox" 
                checked={isWebEditor} 
                onChange={handleToggle} 
              />
              <span className="slider round"></span>
            </label>
            <span className="ms-2">{isWebEditor ? "Web Editor" : "MS Word"}</span>
          </div>
        </div>
      </div>

      <div className="row mt-4">
        <div className="col-12">
          {/* Sub-paragraph */}
          <p>This is the sub-paragraph that goes under the heading. Use the web editor to write content or toggle to MS Word format for a simpler editor.</p>
        </div>
      </div>

      <div className="row">
        <div className="col-12">
          {/* Web Editor or MS Word */}
          {isWebEditor ? (
            <div className="border p-3">
              <h5>Web Editor</h5>
              <textarea className="form-control" rows="6" placeholder="Start writing..."></textarea>
            </div>
          ) : (
            <div className="border p-3">
              <h5>MS Word Style</h5>
              <textarea className="form-control" rows="6" placeholder="Start typing in MS Word style..."></textarea>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ComposeBody;
