
import CounterCard from './components/CounterCard';

const App = () => {
  return <CounterCard />;
};

export default App;