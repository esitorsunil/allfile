import React from "react";
import { useSelector, useDispatch } from "react-redux";
import { setLanguage } from "./languageSlice";

export const LanguageSwitcher = () => {
  const language = useSelector((state) => state.language);
  const dispatch = useDispatch();

  return (
    <select value={language} onChange={(e) => dispatch(setLanguage(e.target.value))}>
      <option value="en">English</option>
      <option value="fr">French</option>
      <option value="es">Spanish</option>
    </select>
  );
};
