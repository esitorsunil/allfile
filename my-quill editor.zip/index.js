import MyQuillEditor from './src/MyQuillEditor';
import './styles/quill-editor.css';
import 'quill/dist/quill.snow.css';

export default MyQuillEditor;
