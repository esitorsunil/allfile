import { useEffect, useRef } from 'react';
import Quill from 'quill';
import 'quill/dist/quill.snow.css';
import html2pdf from 'html2pdf.js';

const Size = Quill.import('formats/size');
Size.whitelist = ['10px', '12px', '14px', '16px', '18px', '24px', '32px', '48px'];
Quill.register(Size, true);

const generateLetter = async (userPrompt) => {
  const response = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: "Bearer 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",
    },
    body: JSON.stringify({
      model: "gpt-3.5-turbo",
      messages: [{ role: "user", content: userPrompt }],
      temperature: 0.7,
      max_tokens: 700,
    }),
  });

  const data = await response.json();
  return data?.choices?.[0]?.message?.content || "No response.";
};

const MyQuillEditor = ({ value, onChange }) => {
  const editorRef = useRef(null);
  const quillRef = useRef(null);
  const toolbarRef = useRef(null);

  const textToHtml = (text) => {
    const paragraphs = text.split(/\n\s*\n/);
    return paragraphs
      .map(p => `<p>${p.replace(/\n/g, '<br>')}</p>`)
      .join('');
  };

  useEffect(() => {
    if (editorRef.current && !quillRef.current) {
      const icons = Quill.import('ui/icons');
      icons['undo'] = `<img src="https://img.icons8.com/ios/50/undo.png" width="18" height="18" alt="undo"/>`;
      icons['redo'] = `<img width="18" height="18" src="https://img.icons8.com/ios/50/redo--v1.png" alt="redo"/>`;

      quillRef.current = new Quill(editorRef.current, {
        theme: 'snow',
        modules: {
          toolbar: {
            container: toolbarRef.current,
            handlers: {
              undo: () => quillRef.current.history.undo(),
              redo: () => quillRef.current.history.redo(),
            },
          },
          history: {
            delay: 1000,
            maxStack: 500,
            userOnly: true,
          },
          keyboard: {
            bindings: {
              undo: {
                key: 'Z',
                shortKey: true,
                handler: () => quillRef.current.history.undo(),
              },
              redo: {
                key: 'Z',
                shortKey: true,
                shiftKey: true,
                handler: () => quillRef.current.history.redo(),
              },
            },
          },
        },
      });

      quillRef.current.on('text-change', () => {
        const html = editorRef.current.querySelector('.ql-editor')?.innerHTML;
        onChange(html || '');
      });

      quillRef.current.root.innerHTML = value;
    }
  }, []);

  useEffect(() => {
    if (quillRef.current && quillRef.current.root.innerHTML !== value) {
      quillRef.current.root.innerHTML = value;
    }
  }, [value]);

  const handleGenerateClick = async () => {
    const prompt = window.prompt("Describe the letter you want:");
    if (!prompt) return;

    const letter = await generateLetter(prompt);
    if (quillRef.current) {
      const letterHtml = textToHtml(letter);
      quillRef.current.clipboard.dangerouslyPasteHTML(letterHtml);
    }
  };

 const handleDownloadPDF = () => {
    const editor = editorRef.current.querySelector('.ql-editor');
    if (!editor) return;

    const opt = {
      margin:       0.5,
      filename:     'letter.pdf',
      image:        { type: 'jpeg', quality: 0.98 },
      html2canvas:  { scale: 2 },
      jsPDF:        { unit: 'in', format: 'letter', orientation: 'portrait' }
    };

    html2pdf().set(opt).from(editor).save();
  };

  return (
    <>
      <div style={{ marginBottom: '10px' }}>
        <button onClick={handleGenerateClick} style={{ marginRight: '10px' }}>
          ✨ Generate Letter
        </button>
        <button onClick={handleDownloadPDF}>
          📄 Download PDF
        </button>
      </div>

      <div ref={toolbarRef} className="custom-toolbar">
        <span className="ql-formats">
          <button className="ql-image" />
          <select className="ql-header" defaultValue="">
            <option value="1" />
            <option value="2" />
            <option value="3" />
            <option value="4" />
            <option value="5" />
            <option value="6" />
            <option value="" />
          </select>
          <select className="ql-size">
            <option value="10px">10px</option>
            <option value="12px">12px</option>
            <option value="14px">14px</option>
            <option value="16px">16px</option>
            <option value="18px">18px</option>
            <option value="24px">24px</option>
            <option value="32px">32px</option>
            <option value="48px">48px</option>
          </select>
        </span>
        <span className="ql-formats">
          <button className="ql-bold" />
          <button className="ql-italic" />
          <button className="ql-underline" />
          <button className="ql-link" />
        </span>
        <span className="ql-formats">
          <button className="ql-list" value="ordered" />
          <button className="ql-list" value="bullet" />
          <select className="ql-align" />
        </span>
        <span className="ql-formats">
          <button className="ql-undo" />
          <button className="ql-redo" />
        </span>
      </div>

      <div
        ref={editorRef}
        style={{ minHeight: '300px', border: '1px solid #ccc', padding: '10px' }}
      />
    </>
  );
};

export default MyQuillEditor;
