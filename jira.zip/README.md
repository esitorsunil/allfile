# Jira like Task Management System

Planning
- Setup prroject
- myTask Page
 - table view
  - edit task
  - create new task
 - calender view
  - individual task page
    - editing task description
    - leading task 
 - add filters
- Members Page
 - view members
  - edit members
- Project Pages
 - edit project
- Setting Page
 - rename worksapce
  - swicher component to navigate different workspace
 - invite system (shareable links)

- Login page (admin)
 - invited button (for members)
<<<<<<< HEAD
=======

>>>>>>> 7c40687 (Landing page, feat: Login auth)
