import React from 'react'

const Tasks = () => {
  return (
    <div>
      <h1>Tasks</h1>
    </div>
  )
}

export default Tasks
