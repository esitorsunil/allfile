import React from 'react'

const Settings = () => {
  return (
    <div>
      settings
    </div>
  )
}

export default Settings
