// components/Workspace.js
import { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { addWorkspace, setCurrentWorkspace, addProject } from '../store/workSpaceSlice';
import WorkspaceSwitcher from './WorkspaceSwitcher';
import ProjectCard from './ProjectCard';

export default function Workspace() {
  const [showWorkspaceModal, setShowWorkspaceModal] = useState(false);
  const [showProjectModal, setShowProjectModal] = useState(false);
  const [workspaceName, setWorkspaceName] = useState('');
  const [projectForm, setProjectForm] = useState({
    name: '',
    key: '',
    description: ''
  });
  
  const dispatch = useDispatch();
  const { workspaces, currentWorkspace } = useSelector((state) => state.workspace);

  const handleCreateWorkspace = () => {
    if (workspaceName.trim()) {
      const newWorkspace = {
        id: Date.now(),
        name: workspaceName,
        projects: []
      };
      dispatch(addWorkspace(newWorkspace));
      dispatch(setCurrentWorkspace(newWorkspace));
      setWorkspaceName('');
      setShowWorkspaceModal(false);
    }
  };

  const handleCreateProject = () => {
    if (projectForm.name.trim() && projectForm.key.trim() && currentWorkspace) {
      const newProject = {
        id: Date.now(),
        ...projectForm,
        createdAt: new Date().toISOString()
      };
      dispatch(addProject({
        workspaceId: currentWorkspace.id,
        project: newProject
      }));
      setProjectForm({ name: '', key: '', description: '' });
      setShowProjectModal(false);
    }
  };
 console.log(handleCreateProject);
  return (
    <div className="container py-4">
      {/* Workspace Switcher */}
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2>
          {currentWorkspace 
            ? `Projects in ${currentWorkspace.name}` 
            : 'Create a workspace'}
        </h2>
        <WorkspaceSwitcher />
      </div>

      {/* Action Buttons */}
      <div className="d-flex justify-content-end gap-2 mb-4">
        <button 
          className="btn btn-primary btn-sm"
          onClick={() => setShowWorkspaceModal(true)}
        >
          <i className="bi bi-plus"></i> Create Workspace
        </button>
        {currentWorkspace && (
          <button 
            className="btn btn-success btn-sm"
            onClick={() => setShowProjectModal(true)}
          >
            <i className="bi bi-plus"></i> Create Project
          </button>
        )}
      </div>

      {/* Projects List */}
      {currentWorkspace?.projects?.length > 0 ? (
        <div className="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
          {currentWorkspace.projects.map(project => (
            <div className="col" key={project.id}>
              <ProjectCard project={project} />
            </div>
          ))}
        </div>
      ) : currentWorkspace ? (
        <div className="alert alert-info">
          No projects yet. Create your first project!
        </div>
      ) : (
        <div className="alert alert-warning">
          Please create or select a workspace first
        </div>
      )}

      {/* Workspace Creation Modal */}
      {showWorkspaceModal && (
        <div className="modal show d-block" tabIndex="-1">
          <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Create New Workspace</h5>
                <button 
                  type="button" 
                  className="btn-close" 
                  onClick={() => setShowWorkspaceModal(false)}
                />
              </div>
              <div className="modal-body">
                <div className="mb-3">
                  <label className="form-label">Workspace Name</label>
                  <input
                    type="text"
                    className="form-control"
                    value={workspaceName}
                    onChange={(e) => setWorkspaceName(e.target.value)}
                    placeholder="Enter workspace name"
                    required
                  />
                </div>
              </div>
              <div className="modal-footer">
                <button 
                  type="button" 
                  className="btn btn-secondary" 
                  onClick={() => setShowWorkspaceModal(false)}
                >
                  Cancel
                </button>
                <button 
                  type="button" 
                  className="btn btn-primary" 
                  onClick={handleCreateWorkspace}
                  disabled={!workspaceName.trim()}
                >
                  Create Workspace
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Project Creation Modal */}
      {showProjectModal && (
        <div className="modal show d-block" tabIndex="-1">
          <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Create New Project</h5>
                <button 
                  type="button" 
                  className="btn-close" 
                  onClick={() => setShowProjectModal(false)}
                />
              </div>
              <div className="modal-body">
                <div className="mb-3">
                  <label className="form-label">Project Name</label>
                  <input
                    type="text"
                    className="form-control"
                    value={projectForm.name}
                    onChange={(e) => setProjectForm({...projectForm, name: e.target.value})}
                    placeholder="e.g. Marketing Website"
                    required
                  />
                </div>
                <div className="mb-3">
                  <label className="form-label">Project Key</label>
                  <input
                    type="text"
                    className="form-control"
                    value={projectForm.key}
                    onChange={(e) => setProjectForm({...projectForm, key: e.target.value.toUpperCase()})}
                    placeholder="e.g. MWEB"
                    maxLength="5"
                    required
                  />
                  <small className="text-muted">Up to 5 uppercase letters</small>
                </div>
                <div className="mb-3">
                  <label className="form-label">Description</label>
                  <textarea
                    className="form-control"
                    value={projectForm.description}
                    onChange={(e) => setProjectForm({...projectForm, description: e.target.value})}
                    rows="3"
                    placeholder="Describe the project..."
                  />
                </div>
              </div>
              <div className="modal-footer">
                <button 
                  type="button" 
                  className="btn btn-secondary" 
                  onClick={() => setShowProjectModal(false)}
                >
                  Cancel
                </button>
                <button 
                  type="button" 
                  className="btn btn-primary" 
                  onClick={handleCreateProject}
                
                  disabled={!projectForm.name.trim() || !projectForm.key.trim()}
                >
                
                  Create Project
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}