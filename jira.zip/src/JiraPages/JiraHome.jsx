import React from 'react'

const JiraHome = () => {
  return (
    <div>
      Home
    </div>
  )
}

export default JiraHome
