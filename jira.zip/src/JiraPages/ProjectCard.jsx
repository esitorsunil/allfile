// components/ProjectCard.js
export default function ProjectCard({ project }) {
    return (
      <div className="card mb-3">
        <div className="card-body">
          <h5 className="card-title">{project.name}</h5>
          <h6 className="card-subtitle mb-2 text-muted">{project.key}</h6>
          <p className="card-text">{project.description}</p>
          <a href={`/project/${project.id}`} className="btn btn-primary btn-sm">
            View Project
          </a>
        </div>
      </div>
    );
  }