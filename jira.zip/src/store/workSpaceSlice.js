// store/workspaceSlice.js
import { createSlice } from '@reduxjs/toolkit';

// Helper function to load from localStorage with fallback
const loadFromLocalStorage = (key, defaultValue = []) => {
  try {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : defaultValue;
  } catch (error) {
    console.error('Error loading from localStorage:', error);
    return defaultValue;
  }
};

const initialState = {
  workspaces: loadFromLocalStorage('workspaces'),
  currentWorkspace: loadFromLocalStorage('currentWorkspace', null)
};

const workspaceSlice = createSlice({
  name: 'workspace',
  initialState,
  reducers: {
    addWorkspace: (state, action) => {
      const newWorkspace = {
        ...action.payload,
        projects: action.payload.projects || [] // Ensure projects array exists
      };
      state.workspaces.push(newWorkspace);
      localStorage.setItem('workspaces', JSON.stringify(state.workspaces));
    },
    setCurrentWorkspace: (state, action) => {
      state.currentWorkspace = {
        ...action.payload,
        projects: action.payload?.projects || [] // Ensure projects array exists
      };
      localStorage.setItem('currentWorkspace', JSON.stringify(state.currentWorkspace));
    },
    addProject: (state, action) => {
      const { workspaceId, project } = action.payload;
      
      // Find the workspace in the array
      const workspaceIndex = state.workspaces.findIndex(w => w.id === workspaceId);
      
      if (workspaceIndex !== -1) {
        // Create a new workspace object with updated projects
        const updatedWorkspace = {
          ...state.workspaces[workspaceIndex],
          projects: [...(state.workspaces[workspaceIndex].projects || []), project] // Safely add project
        };
        
        // Update the workspaces array
        state.workspaces[workspaceIndex] = updatedWorkspace;
        
        // Update current workspace if it's the one being modified
        if (state.currentWorkspace?.id === workspaceId) {
          state.currentWorkspace = updatedWorkspace;
        }
        
        // Persist to localStorage
        localStorage.setItem('workspaces', JSON.stringify(state.workspaces));
        localStorage.setItem('currentWorkspace', JSON.stringify(state.currentWorkspace));
      }
    }
  }
});

export const { addWorkspace, setCurrentWorkspace, addProject } = workspaceSlice.actions;
export default workspaceSlice.reducer;