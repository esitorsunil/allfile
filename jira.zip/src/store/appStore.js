import { configureStore } from "@reduxjs/toolkit";
import languageReducer from "multi-lang-switcher/dist/languageSlice"; // important

export const store = configureStore({
  reducer: {
    language: languageReducer,
  },
});
