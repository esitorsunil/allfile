import React, { useState, useEffect, useCallback } from 'react';
import Timeline from 'react-calendar-timeline';

// Sample groups and items
const groups = [{ id: 1, title: 'Group 1' }, { id: 2, title: 'Group 2' }];

const initialItems = [
  {
    id: 1,
    group: 1,
    title: 'Event 1',
    start_time: new Date('2025-05-27T09:00:00'),
    end_time: new Date('2025-05-27T11:00:00'),
  },
  {
    id: 2,
    group: 2,
    title: 'Event 2',
    start_time: new Date('2025-05-27T13:00:00'),
    end_time: new Date('2025-05-27T14:30:00'),
  },
];

// OpenAI config (replace with your key!)

export default function SmartCalendarTimeline() {
  const [items, setItems] = useState(initialItems);
  const [visibleTimeStart, setVisibleTimeStart] = useState(Date.now() - 86400000 / 2); // half day ago
  const [visibleTimeEnd, setVisibleTimeEnd] = useState(Date.now() + 86400000 / 2); // half day ahead
  const [summary, setSummary] = useState('');
  const [isLoadingSummary, setIsLoadingSummary] = useState(false);

  // Drag and drop handlers
  const handleItemMove = (itemId, dragTime, newGroupOrder) => {
    const group = groups[newGroupOrder].id;
    setItems(prevItems =>
      prevItems.map(item =>
        item.id === itemId
          ? { ...item, start_time: new Date(dragTime), end_time: new Date(dragTime + (item.end_time - item.start_time)), group }
          : item
      )
    );
  };

  // Zoom handlers
  const zoomIn = () => {
    const zoomFactor = 0.5;
    const visibleDuration = visibleTimeEnd - visibleTimeStart;
    const center = visibleTimeStart + visibleDuration / 2;
    const newDuration = visibleDuration * zoomFactor;
    setVisibleTimeStart(center - newDuration / 2);
    setVisibleTimeEnd(center + newDuration / 2);
  };

  const zoomOut = () => {
    const zoomFactor = 2;
    const visibleDuration = visibleTimeEnd - visibleTimeStart;
    const center = visibleTimeStart + visibleDuration / 2;
    const newDuration = visibleDuration * zoomFactor;
    setVisibleTimeStart(center - newDuration / 2);
    setVisibleTimeEnd(center + newDuration / 2);
  };

  // AI summary generation for past events
  const generateSummary = useCallback(async () => {
    setIsLoadingSummary(true);

    // Gather past events (before now)
    const now = Date.now();
    const pastEvents = items.filter(item => item.end_time.getTime() < now);

    if (pastEvents.length === 0) {
      setSummary('No past events to summarize.');
      setIsLoadingSummary(false);
      return;
    }

    // Create a prompt for AI
    const prompt = `Summarize the following past events:\n${pastEvents
      .map(
        (e) =>
          `- ${e.title}: from ${e.start_time.toLocaleString()} to ${e.end_time.toLocaleString()}`
      )
      .join('\n')}`;

    try {
      const completion = await openai.createChatCompletion({
        model: "gpt-4o-mini",
        messages: [{ role: "user", content: prompt }],
        max_tokens: 150,
      });

      setSummary(completion.data.choices[0].message.content);
    } catch (error) {
      setSummary('Failed to generate summary.');
      console.error(error);
    }

    setIsLoadingSummary(false);
  }, [items]);

  useEffect(() => {
    generateSummary();
  }, [generateSummary]);

  return (
    <div>
      <h2>Smart Calendar Timeline</h2>

      <div style={{ marginBottom: '1rem' }}>
        <button onClick={zoomIn}>Zoom In</button>
        <button onClick={zoomOut}>Zoom Out</button>
      </div>

      <Timeline
        groups={groups}
        items={items}
        defaultTimeStart={new Date(visibleTimeStart)}
        defaultTimeEnd={new Date(visibleTimeEnd)}
        visibleTimeStart={visibleTimeStart}
        visibleTimeEnd={visibleTimeEnd}
        onTimeChange={(start, end) => {
          setVisibleTimeStart(start);
          setVisibleTimeEnd(end);
        }}
        canMove={true}
        onItemMove={handleItemMove}
        stackItems
        itemTouchSendsClick={false}
      />

      <div style={{ marginTop: '2rem', padding: '1rem', border: '1px solid #ccc', borderRadius: '5px' }}>
        <h3>AI Summary of Past Events</h3>
        {isLoadingSummary ? <p>Loading summary...</p> : <p>{summary}</p>}
      </div>
    </div>
  );
}
