import React from 'react';
import { useToast } from 'bootstrap-toast-notifications';

function MyComponent() {
  const toast = useToast();

  const handleClick = () => {
    //toast.success('Operation completed successfully!');
    // Other options:
    // toast.info('This is some information');
    // toast.warning('This is a warning');
     toast.error('Something went wrong!');
  };

  return (
    <button onClick={handleClick}>Show Toast</button>
  );
}
export default MyComponent;