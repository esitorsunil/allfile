import React from "react";
import { LanguageSwitcher } from "multi-lang-switcher";

function App() {
  return (
    <div>
      <h1>Language Switcher</h1>
      <LanguageSwitcher />
    </div>
  );
}

export default App;
