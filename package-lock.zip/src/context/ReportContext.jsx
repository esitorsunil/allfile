import React, { createContext, useState } from "react";

// Create the context
export const ReportContext = createContext();

// Create the provider component
export const ReportProvider = ({ children }) => {
  const [reports, setReports] = useState([
    { id: 1, name: "Product A", type: "Sales", status: "Completed", date: "2025-04-10" },
    { id: 2, name: "Product B", type: "Revenue", status: "Pending", date: "2025-04-12" },
    { id: 3, name: "Product C", type: "Orders", status: "Completed", date: "2025-04-15" },
    { id: 4, name: "Product D", type: "Traffic", status: "In Review", date: "2025-04-17" },
  ]);

  const updateReport = (updated) => {
    setReports((prev) =>
      prev.map((r) => (r.id === updated.id ? updated : r))
    );
  };

  return (
    <ReportContext.Provider value={{ reports, updateReport }}>
      {children}
    </ReportContext.Provider>
  );
};
